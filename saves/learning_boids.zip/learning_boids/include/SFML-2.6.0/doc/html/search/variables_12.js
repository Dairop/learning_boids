var searchData=
[
  ['unicode_0',['unicode',['../structsf_1_1Event_1_1TextEvent.html#a00d96b1a5328a1d7cbc276e161befcb0',1,'sf::Event::TextEvent']]]
];
