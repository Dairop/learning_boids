var searchData=
[
  ['hasaxis_0',['hasAxis',['../classsf_1_1Joystick.html#a268e8f2a11ae6af4a47c727cb4ab4d95',1,'sf::Joystick']]],
  ['hasfocus_1',['hasFocus',['../classsf_1_1WindowBase.html#ad87bd19e979c426cb819ccde8c95232e',1,'sf::WindowBase']]],
  ['hasglyph_2',['hasGlyph',['../classsf_1_1Font.html#ae577efa14d9f538208c98ded59a3f68e',1,'sf::Font']]],
  ['http_3',['Http',['../classsf_1_1Http.html#abe2360194f99bdde402c9f97a85cf067',1,'sf::Http::Http()'],['../classsf_1_1Http.html#a79efd844a735f083fcce0edbf1092385',1,'sf::Http::Http(const std::string &amp;host, unsigned short port=0)']]]
];
